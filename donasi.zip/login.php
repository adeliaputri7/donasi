<?php
// Start session untuk menyimpan data pengguna jika login berhasil
session_start();

// Termasuk file db.php untuk koneksi ke database
include('db.php');

// Cek jika form di-submit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangkap data dari form
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Siapkan query untuk mencari email di database
    $sql = "SELECT id, name, email, password FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();
    
    // Cek apakah email ditemukan
    if ($stmt->num_rows > 0) {
        // Ambil data pengguna
        $stmt->bind_result($id, $name, $db_email, $hashed_password);
        $stmt->fetch();
        
        // Verifikasi password yang dimasukkan dengan password yang tersimpan di database
        if (password_verify($password, $hashed_password)) {
            // Jika password cocok, buat session untuk menyimpan data pengguna
            $_SESSION['user_id'] = $id;
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $db_email;

            // Redirect ke halaman dashboard atau halaman yang dilindungi
            header("Location: dashboard.php");
            exit();
        } else {
            // Password salah
            echo "<script>alert('Password salah!'); window.location.href='login.html';</script>";
        }
    } else {
        // Email tidak ditemukan
        echo "<script>alert('Email tidak ditemukan!'); window.location.href='login.html';</script>";
    }

    // Tutup statement dan koneksi
    $stmt->close();
    $conn->close();
}
?>
