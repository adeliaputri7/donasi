<?php
// Mulai session
session_start();

// Cek apakah pengguna sudah login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

echo "Selamat datang, " . $_SESSION['user_name'] . "!";
echo "<br>Email: " . $_SESSION['user_email'];
echo "<br><a href='logout.php'>Logout</a>";
?>
